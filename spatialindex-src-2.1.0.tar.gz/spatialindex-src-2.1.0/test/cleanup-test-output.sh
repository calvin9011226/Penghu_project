#! /bin/sh

rm *.dat *.idx || true
rm data queries res mix || true
